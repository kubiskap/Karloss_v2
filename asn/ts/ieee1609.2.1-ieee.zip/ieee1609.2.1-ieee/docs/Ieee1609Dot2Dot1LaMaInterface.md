# ASN.1 module Ieee1609Dot2Dot1LaMaInterface
 OID: _{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) la-ma(12) major-version-2(2) minor-version-1(1)}_
 @note Section references in this file are to clauses in IEEE Std
 1609.2.1 unless indicated otherwise. Full forms of acronyms and
 abbreviations used in this file are specified in 3.2.
 

## Data Elements:

### <a name="LaMaInterfacePdu"></a>LaMaInterfacePdu
This structure is not used by EEs, so it is defined as NULL for
 purposes of this document.
```asn1
LaMaInterfacePdu ::= NULL
```



