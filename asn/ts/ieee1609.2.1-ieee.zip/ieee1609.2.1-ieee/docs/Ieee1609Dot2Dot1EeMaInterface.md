# ASN.1 module Ieee1609Dot2Dot1EeMaInterface
 OID: _{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) ee-ma(10) major-version-2(2) minor-version-1(1)}_
 @note Section references in this file are to clauses in IEEE Std
 1609.2.1 unless indicated otherwise. Full forms of acronyms and
 abbreviations used in this file are specified in 3.2.
 

## Data Elements:

### <a name="EeMaInterfacePdu"></a>EeMaInterfacePdu
This structure is currently being defined outside of this document,
 so it is defined as NULL for purposes of this document.
```asn1
EeMaInterfacePdu ::= NULL
```



