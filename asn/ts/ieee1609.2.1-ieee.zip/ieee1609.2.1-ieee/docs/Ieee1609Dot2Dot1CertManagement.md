# ASN.1 module Ieee1609Dot2Dot1CertManagement
 OID: _{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) cert-management(7) major-version-3(3) minor-version-1(1)}_
 @note Section references in this file are to clauses in IEEE Std
 1609.2.1 unless indicated otherwise. Full forms of acronyms and
 abbreviations used in this file are specified in 3.2.
 

## Imports:
 * **[Ieee1609Dot2](Ieee1609Dot2.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) base(1) schema(1) major-version-2(2) minor-version-5(5)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2BaseTypes](Ieee1609Dot2BaseTypes.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) base(1) base-types(2) major-version-2(2) minor-version-3(3)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2CrlBaseTypes](Ieee1609Dot2CrlBaseTypes.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) crl(3) base-types(2) major-version-3(3) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Crl](Ieee1609Dot2Crl.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) crl(3) major-version-3(3) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1Protocol](Ieee1609Dot2Dot1Protocol.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) protocol(17) major-version-3(3) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
## Data Elements:
### <a name="CertManagementPdu"></a>CertManagementPdu
This is the parent structure for all SCMS component certificate
 management structures. An overview of this structure is as follows:

Fields:
* compositeCrl of type [**CompositeCrl**](#CompositeCrl) <br>
  contains zero or more SecuredCrl as defined in IEEE
   Std 1609.2, and the CTL.


* certificateChain of type [**CertificateChain**](#CertificateChain) <br>
  contains a collection of certificates and the CTL.


   
* multiSignedCtl of type [**MultiSignedCtl**](#MultiSignedCtl) <br>
  contains the CTL signed by multiple
   signers, the electors.


   
* tbsCtlSignature of type [**ToBeSignedCtlSignature**](#ToBeSignedCtlSignature) <br>
  contains the CTL-instance-specific information used
   to generate a signature on the CTL.
   


   
* infoStatus of type [**CertificateManagementInfoStatus**](#CertificateManagementInfoStatus) <br>
   
```asn1
CertManagementPdu ::= CHOICE {
  compositeCrl      CompositeCrl,
  certificateChain  CertificateChain,
  multiSignedCtl    MultiSignedCtl,
  tbsCtlSignature   ToBeSignedCtlSignature,
  infoStatus        CertificateManagementInfoStatus,
  ...
}
```

### <a name="CompositeCrl"></a>CompositeCrl
This structure is used to encapsulate CRLs and a CTL. An overview
 of this structure is as follows:

Fields:
* crl of type **SEQUENCE**  SIZE(0..MAX) OF SecuredCrl<br>
  contains a list of signed CRLs for different (CRACA ID, CRL
   series) pairs. The CRLs are signed individually, and this document does not
   specify the order in which they should appear.


* homeCtl of type [**MultiSignedCtlSpdu**](Ieee1609Dot2Dot1Protocol.md#MultiSignedCtlSpdu) <br>
  contains a CTL. If the composite CRL was requested via the
   mechanisms given in 6.3.5.8, the CtlSeriesId in this CTL is the same as
   the CtlSeriesId provided in the request. The intent is that this is the
   "home" CTL of the requester, but this field can in practice be used to
   provide any CTL with any CtlSeriesId value.
   


   
```asn1
CompositeCrl ::= SEQUENCE {
  crl      SEQUENCE SIZE(0..MAX) OF SecuredCrl,
  homeCtl  MultiSignedCtlSpdu,
  ...
}
```

### <a name="CertificateChain"></a>CertificateChain
This structure is used to encapsulate certificates and a CTL. An
 overview of this structure is as follows:

Fields:
* homeCtl of type [**MultiSignedCtlSpdu**](Ieee1609Dot2Dot1Protocol.md#MultiSignedCtlSpdu) <br>
  contains a CTL. If the certificate chain was requested via
   the mechanisms given in 6.3.5.7, the CtlSeriesId in this CTL is the
   same as the CtlSeriesId provided in the request. The intent is that
   this is the "home" CTL of the requester, but this field can in practice be
   used to provide any CTL.


* others of type **SEQUENCE**  SIZE(0..MAX) OF Certificate<br>
  contains additional valid certificates of the CAs and the
   MAs chosen by means outside the scope of this document.
   


   
```asn1
CertificateChain ::= SEQUENCE {
  homeCtl  MultiSignedCtlSpdu,
  others   SEQUENCE SIZE(0..MAX) OF Certificate,
  ...
}
```

### <a name="MultiSignedCtl"></a>MultiSignedCtl
This structure a certificate trust list (CTL) signed by multiple
 signers, the electors. An overview of this structure is as follows:

Fields:
* type of type [**IEEE-1609-2-1-MSCTL**](#IEEE-1609-2-1-MSCTL) .&type({
    Ieee1609dot2dot1Ctls
  })<br>
  contains the type of the multi-signed CTL. Only one type of
   multi-signed CTL is supported in this version of this document.


* tbsCtl of type [**IEEE-1609-2-1-MSCTL**](#IEEE-1609-2-1-MSCTL) .&TbsCtl({
    Ieee1609dot2dot1Ctls
  }{@.type})<br>
  contains the CTL contents.


   
* unsigned of type [**IEEE-1609-2-1-MSCTL**](#IEEE-1609-2-1-MSCTL) .&UnsignedCtlMaterial({
    Ieee1609dot2dot1Ctls
  }{@.type})<br>
  contains data that are associated with the CTL and that
   are not included directly in tbsCtl. For example, if the type is
   fullIeeeCtlType, the FullIeeeTbsCtl contains the hashes of the
   certificates, and the certificates themselves are contained in unsigned.


   
* signatures of type **SEQUENCE**  (SIZE(1..MAX)) OF CtlSignatureSpdu<br>
  contains the signatures. How the signatures are
   calculated is specified in the definition of ToBeSignedCtlSignature. The
   number of signatures shall be no more than the number of electors. Each
   signature shall have been generated by a distinct elector.
   


   
```asn1
MultiSignedCtl ::= SEQUENCE {
  type        IEEE-1609-2-1-MSCTL.&type({
    Ieee1609dot2dot1Ctls
  }),
  tbsCtl      IEEE-1609-2-1-MSCTL.&TbsCtl({
    Ieee1609dot2dot1Ctls
  }{@.type}),
  unsigned    IEEE-1609-2-1-MSCTL.&UnsignedCtlMaterial({
    Ieee1609dot2dot1Ctls
  }{@.type}),
  signatures  SEQUENCE (SIZE(1..MAX)) OF CtlSignatureSpdu
}
```

### <a name="IEEE-1609-2-1-MSCTL"></a>IEEE-1609-2-1-MSCTL
This is the ASN.1 Information Object Class used to associate
 multisigned CTL type identifiers, CTL contents, and unsigned material. In
 this structure:

Fields:
* type of type [**Ieee1609dot2dot1MsctlType**](#Ieee1609dot2dot1MsctlType) <br>
  contains the type, an Ieee1609dot2dot1MsctlType.


  contains unsigned material associated with the
   CTL, as specified in 7.3.11.
   


   
     &TbsCtl,
```asn1
IEEE-1609-2-1-MSCTL ::= CLASS {
  &type                 Ieee1609dot2dot1MsctlType,
  &TbsCtl,
  &UnsignedCtlMaterial
} WITH SYNTAX {&TbsCtl IDENTIFIED BY &type USING &UnsignedCtlMaterial}
```

### <a name="Ieee1609dot2dot1Ctls"></a>Ieee1609dot2dot1Ctls
This is the Information Object Set containing the instances of the
 IEEE-1609-2-1-MSCTL class that are specified for use. Only one instance is
 specified for use in this version of this document.

Fields:
* fullIeeeCtl of type [**USING**](#USING)  SequenceOfCertificate}<br>
   {FullIeeeTbsCtl IDENTIFIED BY
```asn1
Ieee1609dot2dot1Ctls IEEE-1609-2-1-MSCTL ::= {
  {FullIeeeTbsCtl IDENTIFIED BY
    fullIeeeCtl USING SequenceOfCertificate},
  ...
}
```


### <a name="Ieee1609dot2dot1MsctlType"></a>Ieee1609dot2dot1MsctlType
This is the integer used to identify the type of the CTL.
```asn1
Ieee1609dot2dot1MsctlType ::= INTEGER (0..255)
```

```asn1
fullIeeeCtl  Ieee1609dot2dot1MsctlType ::= 1
```

### <a name="FullIeeeTbsCtl"></a>FullIeeeTbsCtl
This structure specifies a CTL that contains information about the
 complete set of certificates trusted by the electors that sign the CTL. An
 overview of this structure is as follows:



   - Any root CA or elector certificate that is not on the CTL is
 not trusted. The electorRemove and rootCaRemove are intended to be used
 only if the SCMS manager wants to explicitly indicate that a previously
 trusted entity (elector or root CA) is now not trusted even though that
 entity's certificate is still within its validity period. In practice, it
 is anticipated that the remove fields (electorRemove and rootCaRemove)
 will almost always be sequences of length 0.

Fields:
* type of type [**Ieee1609dot2dot1MsctlType**](#Ieee1609dot2dot1MsctlType) (fullIeeeCtl)<br>
  contains the type of the CTL. It is identical to the type
   field that appears in the enclosing MultiSignedCtl. The field is included
   here as well to provide the simplest mechanism to help ensure that the
   type is included in the calculated CTL hash.


* ctlSeriesId of type [**CtlSeriesId**](#CtlSeriesId) <br>
   
* sequenceNumber of type [**CtlSequenceNumber**](#CtlSequenceNumber) <br>
  contains the sequence number of the CTL. This is
   incremented by 1 every time a new FullIeeeTbsCtl is issued.


   
* effectiveDate of type [**Time32**](Ieee1609Dot2BaseTypes.md#Time32) <br>
  contains the time when the CTL is to take effect.
   This is to be greater than or equal to the effectiveDate field in the CTL
   with the same CtlSeriesId and the previous sequence number.


   
* electorApprove of type **SEQUENCE**  OF CtlElectorEntry<br>
  contains the list of hashes of the elector
   certificates that are approved as of the effective date. The hash is
   calculated with the same hash algorithm that is used to hash the elector
   certificate for signing.


   
* electorRemove of type **SEQUENCE**  OF CtlElectorEntry<br>
  contains the list of hashes of the elector
   certificates that are valid (that is, not expired) on the effective date and
   are not approved, as of the effective date, to sign a CTL. The hash is
   calculated with the same hash algorithm that is used to hash the elector
   certificate for signing. This field is to be considered informational as a
   certificate that is not included in electorApprove is not valid even if it
   does not appear in electorRemove.


   
* rootCaApprove of type **SEQUENCE**  OF CtlRootCaEntry<br>
  contains the list of root CA certificates that are
   approved as of the effective date. The hash is calculated with the same
   hash algorithm that is used to hash the root certificate for signing. If
   the root certificate is signed with a hash function with a 48 octet
   output, this is truncated to the low-order 32 bytes for inclusion in the
   CTL.


   
* rootCaRemove of type **SEQUENCE**  OF CtlRootCaEntry<br>
  contains the list of root CA certificates that are
   valid (that is, not expired) on the effective date and are not approved, as
   of the effective date, to issue certificates or carry out other
   activities. If the root certificate is signed with a hash function
   with a 48 octet output, this is truncated to the low-order 32 bytes for
   inclusion in the CTL. This field is to be considered informational as a
   certificate that is not included in rootCaApprove is not valid even if it
   does not appear in rootCaRemove.


   
* quorum of type **INTEGER** <br>
  contains the quorum, that is, the number of the electors
   required to sign the next CTL with the same CtlSeriesId value for that
   CTL to be trusted. If this field is absent, the quorum for the next CTL
   shall be the quorum for the current CTL.
   


   
     ...,

>>>
NOTE:&emsp;   - If in future CTL types are defined that contain the same
 information as, or a subset of the information in, the fullIeeeCtl, those
 types are anticipated to contain the same sequence number as the
 corresponding fullIeeeCtl.
>>>
```asn1
FullIeeeTbsCtl ::= SEQUENCE {
  type            Ieee1609dot2dot1MsctlType(fullIeeeCtl),
  ctlSeriesId     CtlSeriesId,
  sequenceNumber  CtlSequenceNumber,
  effectiveDate   Time32,
  electorApprove  SEQUENCE OF CtlElectorEntry,
  electorRemove   SEQUENCE OF CtlElectorEntry,
  rootCaApprove   SEQUENCE OF CtlRootCaEntry,
  rootCaRemove    SEQUENCE OF CtlRootCaEntry,
  ...,
  quorum          INTEGER
}
```


### <a name="CtlSeriesId"></a>CtlSeriesId
This structure identifies a group of electors that sign a series of
 CTLs for a specific purpose. Registration of CtlSeriesId values is
 managed by the IEEE RA; see http://standards.ieee.org/regauth. A list of
 assigned CtlSeriesId values is provided in K.1.
```asn1
CtlSeriesId ::= OCTET STRING (SIZE(8))
```


### <a name="CtlSequenceNumber"></a>CtlSequenceNumber
This structure is used to encode the CTL sequence number. This
 document does not specify semantics of this type once it reaches its
 maximum value.
```asn1
CtlSequenceNumber ::= INTEGER(0..65535)
```


### <a name="CtlElectorEntry"></a>CtlElectorEntry
This structure contains the hash of an elector certificate.
```asn1
CtlElectorEntry ::= HashedId48
```


### <a name="CtlRootCaEntry"></a>CtlRootCaEntry
This structure contains the hash of a root CA certificate.
```asn1
CtlRootCaEntry ::= HashedId32
```

### <a name="ToBeSignedCtlSignature"></a>ToBeSignedCtlSignature
This structure contains the CTL-instance-specific information used
 to generate a signature on the CTL. An overview of this structure is as
 follows:

Fields:
* ctlSeriesId of type [**CtlSeriesId**](#CtlSeriesId) <br>
  contains the CtlSeriesId that appears in the CTL.


* ctlType of type [**Ieee1609dot2dot1MsctlType**](#Ieee1609dot2dot1MsctlType) <br>
  identifies the type of the CTL.


   
* sequenceNumber of type [**CtlSequenceNumber**](#CtlSequenceNumber) <br>
  contains the sequence number of the CTL being signed.


   
* tbsCtlHash of type [**HashedId48**](Ieee1609Dot2BaseTypes.md#HashedId48) <br>
  contains the hash of the C-OER encoded tbsCtl field
   in the MultiSignedCtl. The hash is calculated using the same hash
   algorithm that is used to generate the signature on this structure when it
   is contained in a CtlSignatureSpdu. This algorithm can be determined from
   the headers of the CtlSignatureSpdu.
   


   
```asn1
ToBeSignedCtlSignature ::= SEQUENCE {
  ctlSeriesId     CtlSeriesId,
  ctlType         Ieee1609dot2dot1MsctlType,
  sequenceNumber  CtlSequenceNumber,
  tbsCtlHash      HashedId48
}
```

### <a name="CertificateManagementInfoStatus"></a>CertificateManagementInfoStatus
This structure contains the status of different certificate
 management information, including CRLs, CTLs, and individual certificates
 of CAs, MAs, and the RA.

Fields:
* crl of type [**SequenceOfCrlInfoStatus**](#SequenceOfCrlInfoStatus) <br>
  contains the status information for CRLs.


* ctl of type [**SequenceOfCtlInfoStatus**](#SequenceOfCtlInfoStatus) <br>
  contains the status information for CTLs.


   
* caCcf of type [**Time32**](Ieee1609Dot2BaseTypes.md#Time32) <br>
  contains the time of the last update of any of the CA
   certificates in the CCF.


   
* ma of type [**SequenceOfMaInfoStatus**](#SequenceOfMaInfoStatus) <br>
  contains the status information for MA certificates.


   
* ra of type [**Time32**](Ieee1609Dot2BaseTypes.md#Time32)  OPTIONAL<br>
  shall be present and contain the time of last update of the RA's
   certificate, if this structure is sent by an RA.
   


   
```asn1
CertificateManagementInfoStatus ::= SEQUENCE {
  crl    SequenceOfCrlInfoStatus,
  ctl    SequenceOfCtlInfoStatus,
  caCcf  Time32,
  ma     SequenceOfMaInfoStatus,
  ra     Time32 OPTIONAL,
  ...
}
```


### <a name="SequenceOfCtlInfoStatus"></a>SequenceOfCtlInfoStatus
This type is used for clarity of definitions.
```asn1
SequenceOfCtlInfoStatus ::= SEQUENCE OF CtlInfoStatus
```

### <a name="CtlInfoStatus"></a>CtlInfoStatus
This structure contains the status information for a CTL.

Fields:
* ctlSeriesId of type [**CtlSeriesId**](#CtlSeriesId) <br>
  contains the elector group ID of the CTL.


* sequenceNumber of type [**CtlSequenceNumber**](#CtlSequenceNumber) <br>
  contains the sequence number of the CTL.


   
* lastUpdate of type [**Time32**](Ieee1609Dot2BaseTypes.md#Time32) <br>
  contains the time of the last update of the CTL.
   


   
```asn1
CtlInfoStatus ::= SEQUENCE {
  ctlSeriesId     CtlSeriesId,
  sequenceNumber  CtlSequenceNumber,
  lastUpdate      Time32,
  ...
}
```


### <a name="SequenceOfCrlInfoStatus"></a>SequenceOfCrlInfoStatus
This type is used for clarity of definitions.
```asn1
SequenceOfCrlInfoStatus ::= SEQUENCE OF CrlInfoStatus
```

### <a name="CrlInfoStatus"></a>CrlInfoStatus
This structure contains the status information for a CRL.

Fields:
* cracaId of type [**HashedId8**](Ieee1609Dot2BaseTypes.md#HashedId8) <br>
  contains the CRACA ID of the CRL.


* series of type [**CrlSeries**](Ieee1609Dot2CrlBaseTypes.md#CrlSeries) <br>
  contains the CRL series of the CRL.


   
* issueDate of type [**Time32**](Ieee1609Dot2BaseTypes.md#Time32) <br>
  contains the time of the last update of the CRL.
   


   
```asn1
CrlInfoStatus ::= SEQUENCE {
  cracaId    HashedId8,
  series     CrlSeries,
  issueDate  Time32,
  ...
}
```


### <a name="SequenceOfMaInfoStatus"></a>SequenceOfMaInfoStatus
This type is used for clarity of definitions.
```asn1
SequenceOfMaInfoStatus ::= SEQUENCE OF MaInfoStatus
```

### <a name="MaInfoStatus"></a>MaInfoStatus
This structure contains the status information for an MA's
 certificate.

Fields:
* psids of type [**SequenceOfPsid**](Ieee1609Dot2Dot1Protocol.md#SequenceOfPsid) <br>
  contains the PSIDs associated with the misbehavior that is to
   be reported to that MA.


* updated of type [**Time32**](Ieee1609Dot2BaseTypes.md#Time32) <br>
  contains the time of the last update of the MA's certificate.
   


   
```asn1
MaInfoStatus ::= SEQUENCE {
  psids    SequenceOfPsid,
  updated  Time32,
  ...
}
```



This type is used for clarity of definitions.
  This structure contains the status information for a CRL.

 @param cracaId: contains the CRACA ID of the CRL.

 @param series: contains the CRL series of the CRL.

 @param issueDate: contains the time of the last update of the CRL.
  This type is used for clarity of definitions.
  This structure contains the status information for an MA's
 certificate.

 @param psids: contains the PSIDs associated with the misbehavior that is to
 be reported to that MA.

 @param updated: contains the time of the last update of the MA's certificate.


