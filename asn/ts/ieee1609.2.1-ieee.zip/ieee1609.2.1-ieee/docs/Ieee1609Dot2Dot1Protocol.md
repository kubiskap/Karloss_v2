# ASN.1 module Ieee1609Dot2Dot1Protocol
 OID: _{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) protocol(17) major-version-3(3) minor-version-1(1)}_
 @note Section references in this file are to clauses in IEEE Std
 1609.2.1 unless indicated otherwise. Full forms of acronyms and
 abbreviations used in this file are specified in 3.2.
 

## Imports:
 * **[Ieee1609Dot2](Ieee1609Dot2.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) base(1) schema(1) major-version-2(2) minor-version-5(5)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2BaseTypes](Ieee1609Dot2BaseTypes.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) base(1) base-types(2) major-version-2(2) minor-version-3(3)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1AcaEeInterface](Ieee1609Dot2Dot1AcaEeInterface.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) aca-ee(1) major-version-2(2) minor-version-3(3)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1AcaLaInterface](Ieee1609Dot2Dot1AcaLaInterface.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) aca-la(2) major-version-2(2) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1AcaMaInterface](Ieee1609Dot2Dot1AcaMaInterface.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) aca-ma(3) major-version-2(2) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1AcaRaInterface](Ieee1609Dot2Dot1AcaRaInterface.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) aca-ra(4) major-version-3(3) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1Acpc](Ieee1609Dot2Dot1Acpc.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) acpc(18) major-version-3(3) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1CertManagement](Ieee1609Dot2Dot1CertManagement.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) cert-management(7) major-version-3(3) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1EcaEeInterface](Ieee1609Dot2Dot1EcaEeInterface.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) eca-ee(9) major-version-3(3) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1EeMaInterface](Ieee1609Dot2Dot1EeMaInterface.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) ee-ma(10) major-version-2(2) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1EeRaInterface](Ieee1609Dot2Dot1EeRaInterface.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) ee-ra(11) major-version-3(3) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1LaMaInterface](Ieee1609Dot2Dot1LaMaInterface.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) la-ma(12) major-version-2(2) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1LaRaInterface](Ieee1609Dot2Dot1LaRaInterface.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) la-ra(13) major-version-2(2) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1MaRaInterface](Ieee1609Dot2Dot1MaRaInterface.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) ma-ra(14) major-version-2(2) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
## Data Elements:

### <a name="SecurityMgmtPsid"></a>SecurityMgmtPsid
This PSID, 0x23, identifies security management activities as
 defined in this document.
```asn1
SecurityMgmtPsid ::= Psid (35)
```

### <a name="ScmsPdu"></a>ScmsPdu
This is the parent structure that encompasses all parent structures
 of interfaces defined in the SCMS. An overview of this structure is as
 follows:
   - aca-ee contains the interface structures defined for interaction
 between the ACA and the EE.
   - aca-la contains the interface structures defined for interaction
 between the ACA and the LA.
   - aca-ma contains the interface structures defined for interaction
 between the ACA and the MA.
   - aca-ra contains the interface structures defined for interaction
 between the ACA and the RA.
   - cert contains the interface structures defined for certificate
 management.
   - eca-ee contains the interface structures defined for interaction
 between the ECA and the EE.
   - ee-ma contains the interface structures defined for interaction
 between the EE and the MA.
   - ee-ra contains the interface structures defined for interaction
 between the EE and the RA.
   - la-ma contains the interface structures defined for interaction
 between the LA and the MA.
   - la-ra contains the interface structures defined for interaction
 between the LA and the RA.
   - ma-ra contains the interface structures defined for interactions
 between the MA and the RA.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
  contains the current version of the structure.
   


* content of type [**CHOICE**](#CHOICE)  {
    aca-ee  AcaEeInterfacePdu,
    aca-la  AcaLaInterfacePdu,
    aca-ma  AcaMaInterfacePdu,
    aca-ra  AcaRaInterfacePdu,
    cert    CertManagementPdu,
    eca-ee  EcaEeInterfacePdu,
    ee-ma   EeMaInterfacePdu,
    ee-ra   EeRaInterfacePdu,
    la-ma   LaMaInterfacePdu,
    la-ra   LaRaInterfacePdu,
    ma-ra   MaRaInterfacePdu,
    ...
  }<br>
   
```asn1
ScmsPdu ::= SEQUENCE {
  version  Uint8 (2),
  content  CHOICE {
    aca-ee  AcaEeInterfacePdu,
    aca-la  AcaLaInterfacePdu,
    aca-ma  AcaMaInterfacePdu,
    aca-ra  AcaRaInterfacePdu,
    cert    CertManagementPdu,
    eca-ee  EcaEeInterfacePdu,
    ee-ma   EeMaInterfacePdu,
    ee-ra   EeRaInterfacePdu,
    la-ma   LaMaInterfacePdu,
    la-ra   LaRaInterfacePdu,
    ma-ra   MaRaInterfacePdu,
    ...
  }
}
```


### <a name="ScmsPdu-Scoped"></a>ScmsPdu-Scoped
This structure defines a parameterized type for creating a scoped
 data as a subtype of ScmsPdu.
```asn1
ScmsPdu-Scoped {Pdu} ::= ScmsPdu (WITH COMPONENTS {
  ...,
  content (CONSTRAINED BY {
    Pdu
  })
})
```


### <a name="X509Certificate"></a>X509Certificate
This structure defines a parameterized type for creating an
 unsecured data as a subtype of Ieee1609Dot2Data.

This structure defines a parameterized type for creating a signed
 data as a subtype of Ieee1609Dot2Data.

This structure defines a parameterized type for creating an
 encrypted data as a subtype of Ieee1609Dot2Data. An overview of this
 structure is as follows:
This structure defines a parameterized type for creating a signed
 certificate request as a subtype of Ieee1609Dot2Data.

This structure is a wrapper for an ITU-T X.509 certificate.

>>>
NOTE:&emsp;ITU-T X.509 certificates are encoded with the ASN.1 DER
 rather than the OER used in this document and so cannot be "directly"
 imported into these structures.
>>>
```asn1
X509Certificate ::= OCTET STRING
```

### <a name="X509SignerIdentifier"></a>X509SignerIdentifier
This type is used for clarity of definitions.

This structure identifies an ITU-T X.509 certificate used to sign a
 signed data structure. The only data structure currently defined that can
 be signed by an ITU-T X.509 certificate is SignedX509CertificateRequest.

Fields:
* certificate of type [**SequenceOfX509Certificate**](#SequenceOfX509Certificate) <br>
```asn1
X509SignerIdentifier ::= CHOICE {
  certificate  SequenceOfX509Certificate,
  ...
}
```


### <a name="SignerSingleCert"></a>SignerSingleCert
This structure defines a parameterized type for creating a
 certificate request, signed with an ITU-T X.509 certificate, as a subtype of
 Ieee1609Dot2Data. It makes use of the extension of Ieee1609Dot2Content
 defined in 11.2.3.

This structure defines a parameterized type for creating a signed
 then encrypted data as a subtype of Ieee1609Dot2Data.

This structure defines a parameterized type for creating an
 encrypted then signed data as a subtype of Ieee1609Dot2Data.


This structure defines a parameterized type for creating a signed
 then encrypted certificate request as a subtype of Ieee1609Dot2Data.

This structure defines a parameterized type for creating an
 encrypted data as a subtype of Ieee1609Dot2Data. An overview of this
 structure is as follows:
This structure is used to indicate a SignerIdentifier with a
 certificate chain of size 1.

>>>
NOTE:&emsp;This parameterized type inadvertently adds some overhead.
 The Ieee1609Dot2Data-EncryptedSigned {Tbes, Psid} structure, because it
 puts Ieee1609Dot2Data-Encrypted inside Ieee1609Dot2Data-Signed {Tbs, Psid},
 and because Ieee1609Dot2Data-Signed {Tbs, Psid} puts Tbs inside
 unsecuredData, Tbes is "Signed (Unsecured (Encrypted))" instead of
 "Signed (Encrypted))", which was the intent and also in the original CAMP
 design. Other documents that use this document may be better off defining
 this structure on their own, if they want avoid this overhead.
>>>
```asn1
SignerSingleCert ::= SignerIdentifier (WITH COMPONENTS {
  certificate (SequenceOfCertificate (SIZE (1)))
})
```


### <a name="SignerSingleX509Cert"></a>SignerSingleX509Cert
This structure is used to indicate an X509SignerIdentifier with a
 certificate chain of size 1.
```asn1
SignerSingleX509Cert ::= X509SignerIdentifier (WITH COMPONENTS {
  certificate (SequenceOfX509Certificate (SIZE (1)))
})
```


### <a name="SignerSelf"></a>SignerSelf
This structure is used to indicate a SignerIdentifier of type self.
```asn1
SignerSelf ::= SignerIdentifier (WITH COMPONENTS {
  self
})
```


### <a name="ScopedCertificateRequest"></a>ScopedCertificateRequest
This structure defines the all certificate request structures as a
 scoped version of the ScmsPdu.
```asn1
ScopedCertificateRequest ::= ScmsPdu (
  ScmsPdu-Scoped {
    AcaRaInterfacePdu (WITH COMPONENTS {
      raAcaCertRequest
    })
  } |
  ScmsPdu-Scoped {
    EcaEeInterfacePdu (WITH COMPONENTS {
      eeEcaCertRequest
    })
  } |
  ScmsPdu-Scoped {
    EeRaInterfacePdu (WITH COMPONENTS {
      eeRaCertRequest
    })
  } |
  ScmsPdu-Scoped {
    EeRaInterfacePdu (WITH COMPONENTS {
      eeRaSuccessorEnrollmentCertRequest
    })
  }
)
```

### <a name="SignedCertificateRequest"></a>SignedCertificateRequest
This structure defines the format of a signed certificate request.
 An overview of this structure is as follows:


 The signature is generated on the hash of this structure, obtained
 per the rules specified for hashing data objects in 5.3.1 of IEEE Std
 1609.2a-2017, where the parameter Data Input shall be the C-OER
 encoding of tbsRequest, and the parameter Signer Identifier Input
 depending on whether the request is self-signed or signed using an
 enrollment certificate:
   - If the request is self-signed, the parameter Signer Identifier
 Input shall be the empty string, i.e., a string of length 0.
   - If the request is signed using an enrollment certificate, the
 parameter Signer Identifier Input shall be the signer's enrollment
 certificate.

Fields:
* hashAlgorithmId of type [**HashAlgorithm**](Ieee1609Dot2BaseTypes.md#HashAlgorithm) <br>
  contains the identifier of the hash algorithm used
   to calculate the hash of tbsRequest.


* tbsRequest of type [**ScopedCertificateRequest**](#ScopedCertificateRequest) <br>
  contains the certificate request information that is
   signed by the recipient.


   
* signer of type [**SignerIdentifier**](Ieee1609Dot2.md#SignerIdentifier) <br>
  denotes the signing entity's identifier.


   
* signature of type [**Signature**](Ieee1609Dot2BaseTypes.md#Signature) <br>
  contains the request sender's signature.
   


   
```asn1
SignedCertificateRequest ::= SEQUENCE {
  hashAlgorithmId  HashAlgorithm,
  tbsRequest       ScopedCertificateRequest,
  signer           SignerIdentifier,
  signature        Signature
}
```

### <a name="SignedX509CertificateRequest"></a>SignedX509CertificateRequest
This structure contains a certificate request signed with an ITU-T
 X.509 certificate. The only type of certificate request signed with an
 ITU-T X.509 certificate supported in this document is an authorization
 certificate request. An overview of this structure is as follows:


 The signature is generated on the hash of this structure, obtained
 per the rules specified for hashing data objects in 5.3.1 of IEEE Std
 1609.2a-2017, where the parameter Data Input shall be  the C-OER
 encoding of tbsRequest, and the parameter Signer Identifier Input
 shall be  the signer's certificate, that is, the ITU-T X.509 certificate
 contained in the OCTET STRING indicated by the first X509Certificate in
 signer. For example, if the signer is as below, the first 6 bytes are the
 ASN.1 encoding overhead, where 80 01 01 is the overhead for signer, and
 then 82 01 AC is the overhead introduced by the OCTET STRING encoding for
 the first (in this case, the only) X509Certificate; and the first
 X509Certificate is contained in the next 428 bytes (30 82 01 ... 00 00 00),
 so the parameter Signer Identifier Input shall be '30 82 01 ... 00 00 00'.

 An example X509SignerIdentifier with one X509Certificate:

 80 01 01 82 01 AC 30 82 01 A8 30 82 01 4D A0 03 02 01 02 02 04 90
 C5 9D 21 30 0A 06 08 2A 86 48 CE 3D 04 03 02 30 24 31 0A 30 08 06 03 55 04
 06 13 01 00 31 0A 30 08 06 03 55 04 0A 13 01 00 31 0A 30 08 06 03 55 04 03
 13 01 00 30 1E 17 0D 30 30 30 31 30 31 30 30 30 30 30 30 5A 17 0D 30 30 30
 31 30 31 30 30 30 30 30 30 5A 30 24 31 0A 30 08 06 03 55 04 06 13 01 00 31
 0A 30 08 06 03 55 04 0A 13 01 00 31 0A 30 08 06 03 55 04 03 13 01 00 30 59
 30 13 06 07 2A 86 48 CE 3D 02 01 06 08 2A 86 48 CE 3D 03 01 07 03 42 00 00
 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
 00 00 00 00 00 00 00 00 00 00 00 00 00 00 A3 6D 30 6B 30 0A 06 03 55 1D 0E
 04 03 04 01 00 30 0A 06 03 55 1D 23 04 03 04 01 00 30 0C 06 03 55 1D 13 01
 01 FF 04 02 30 00 30 0E 06 03 55 1D 0F 01 01 FF 04 04 03 02 03 C8 30 0A 06
 03 55 1D 25 04 03 04 01 00 30 0A 06 03 55 1D 1F 04 03 04 01 00 30 0F 06 08
 2B 06 01 05 05 07 01 01 04 03 04 01 00 30 0A 06 03 55 1D 20 04 03 04 01 00
 30 0A 06 08 2A 86 48 CE 3D 04 03 02 03 49 00 00 00 00 00 00 00 00 00 00 00
 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
 00 00 00 00 00 00 00 00 00 00 00 00

Fields:
* hashAlgorithmId of type [**HashAlgorithm**](Ieee1609Dot2BaseTypes.md#HashAlgorithm) <br>
  contains the identifier of the hash algorithm used
   inside the binary tree.


* tbsRequest of type [**ScopedCertificateRequest**](#ScopedCertificateRequest) <br>
  contains the certificate request information that is
   signed by the recipient.


   
* signer of type [**X509SignerIdentifier**](#X509SignerIdentifier) <br>
  denotes the signing entity's identifier.


   
* signature of type [**Signature**](Ieee1609Dot2BaseTypes.md#Signature) <br>
  contains the request sender's signature.
   


   
```asn1
SignedX509CertificateRequest ::= SEQUENCE  {
  hashAlgorithmId  HashAlgorithm,
  tbsRequest       ScopedCertificateRequest,
  signer           X509SignerIdentifier,
  signature        Signature
}
```


### <a name="AcaEeCertResponsePlainSpdu"></a>AcaEeCertResponsePlainSpdu
This structure contains a certificate response for consumption by
 the EE. In the architecture of this document, although it is created by the
 ACA, it is made available to the EE via the RA as described in 8.2.


 The ACA creates this response when 1) the compact unified
 butterfly key mechanism is not being used (that is, some other flavor of
 butterfly key is being used, or butterfly keys are not being used) and 2)
 it is not necessary to protect the EE's privacy from the RA, for example,
 when the certificate being returned is not a pseudonym certificate.
```asn1
AcaEeCertResponsePlainSpdu ::= Ieee1609Dot2Data-Unsecured {
  ScmsPdu-Scoped {
    AcaEeInterfacePdu (WITH COMPONENTS {
      acaEeCertResponse
    })
  }
}
```


### <a name="AcaEeCertResponsePrivateSpdu"></a>AcaEeCertResponsePrivateSpdu
This structure contains a certificate response for consumption by
 the EE. In the architecture of this document, although it is created by the
 ACA, it is made available to the EE via the RA as described in 8.2.


 The ACA creates this response when 1) the compact unified
 butterfly key mechanism is not being used (that is, some other flavor of
 butterfly key is being used, or butterfly keys are not being used) and 2)
 it is necessary to protect the EE's privacy from the RA, for example when
 the certificate being returned is a pseudonym certificate.

 The structure consists of a signed SPDU containing an encrypted
 SPDU.

 The encrypted SPDU is encrypted with the response
 encryption key that was provided to the ACA for that purpose. This key is
 determined as follows:
   - If the original EeRaCertRequest from the end entity indicated a single
 response encryption key, that is, if the additionalParams.encryptionKey
 field was present in the request, then the response is encrypted with that
 key.
   - If the original EeRaCertRequest from the end entity indicated a
 response encryption key generated with the "original" butterfly key
 mechanism, that is, the additionalParams.original field was provided in the
 request, then the response is encrypted with the cocoon encryption key
 derived from additionalParams.original.encryptionKey and
 additionalParams.original.encryptionExpansion as specified in 9.3.4.2
 and the corresponding decryption private key is derived as specified in
 9.3.4.1.
   - If the original EeRaCertRequest from the end entity indicated a
 response encryption key generated with the "unified" butterfly key
 mechanism, that is, the additionalParams.unified field was provided in the
 request, then the response is encrypted with the cocoon encryption key
 derived from tbsCert.verifyKeyIndicator and additionalParams.unified as
 specified in 9.3.4.2 and the corresponding decryption private key is
 derived as specified in 9.3.4.1.

 See 9.3 for more material about butterfly keys.

 The resulting Ieee1609Dot2Data of content type encryptedData is
 signed by the same ACA certificate that was used to issue the certificate
 field in the AcaEeCertResponse. If this structure is signed by a different
 ACA certificate, it is invalid. The ACA certificate shall follow the ACA
 certificate profile given in 7.7.3.2.


   - How the ACA obtains the response encryption key: This
 document provides the RaAcaCertRequest structure to allow the RA to
 indicate whether the original or unified butterfly key mechanism is to be
 used via the flags field. The encryption key for encrypting
 AcaEeCertResponse is calculated by the indicated method even if the RA
 does not use an RaAcaCertRequest as defined in this document to
 communicate the certificate request to the ACA.

   - Consistency between inner and outer signers, and the IEEE
 Std 1609.2 model. This SPDU introduces a new type of validity condition
 by requiring that the ACA that signs the outer signed SPDU is also the ACA
 that issued the certificate inside the encrypted SPDU. This requires that
 to verify the inner "SPDU", that is, the certificate, the verifier
 needs to store the information from the outer SPDU. This is not a violation
 of the IEEE 1609.2 model: Subclause 4.2.2.3 of IEEE Std 1609.2 considers all
 operations carried out on received data to be atomic and does not put any
 restrictions on the information that is stored between operations. However,
 it should be noted that because the IEEE 1609.2 approach enables SPDUs to
 be nested within one another as Ieee1609Dot2Data, in principle an
 implementation could be built that iterated through the layers of a nested
 SPDU within a single call from the invoking application instance. (And it
 should also be noted that IEEE Std 1609.2 was consciously designed to
 enable this approach: Although the primitives provided in IEEE Std 1609.2
 only support the series-of-single-operations approach, an implementation
 could layer this "one-invocation processing" on top of the IEEE 1609.2
 interface as an optimization.) A "one-invocation processing" implementation
 of that type would have to anticipate situations of coupling between inner
 and outer SPDUs like the one created by this AcaEeCertResponsePrivateSpdu,
 and allow the invoking certificate management service to check consistency
 at the application layer, perhaps by (for example) returning the signing
 certificates for all nested signed SPDUs. How this is to be implemented is
 implementation specific; this note is intended as a notification of this
 potential issue to implementers planning to implement one-invocation
 processing.

>>>
NOTE:&emsp;   - Other potential responses to an authorization certificate
 request: If the original request indicated the use of "compact unified"
 butterfly key mechanism by including the additionalParams.compactUnified
 field, the response shall be a AcaEeCertResponseCubkSpdu, not a
 AcaEeCertResponsePrivateSpdu.
>>>
```asn1
AcaEeCertResponsePrivateSpdu ::= Ieee1609Dot2Data-EncryptedSigned {
  ScmsPdu-Scoped {
    AcaEeInterfacePdu (WITH COMPONENTS {
      acaEeCertResponse
    })
  },
  SecurityMgmtPsid
}
```


### <a name="AcaEeCertResponseCubkSpdu"></a>AcaEeCertResponseCubkSpdu
This structure contains a certificate response for consumption by
 the EE. In the architecture of this document, although it is created by
 the ACA, it is made available to the EE via the RA as described in 8.2.


 The ACA creates a certificate response in this form when the
 compact unified butterfly key mechanism is being used. If the
 RaAcaCertRequest structure was used to communicate between the RA and the
 ACA, the RA indicated use of compact unified butterfly keys by setting the
 cubk (1) bit in the bkType field in the corresponding RaAcaCertRequest.

 The AcaEeCertResponse is encrypted by the ACA using the cocoon
 public key for encryption. See 9.3.4.2 for how the ACA derives the cocoon
 public key for encryption, using the tbsCert.verifyKeyIndicator field in the
 corresponding RaAcaCertRequest as the input cocoon public key for signing
 Bt. See 9.3.4.1 for how the EE derives the corresponding cocoon private
 key for encryption.
```asn1
AcaEeCertResponseCubkSpdu ::= Ieee1609Dot2Data-Encrypted {
  ScmsPdu-Scoped {
    AcaEeInterfacePdu (WITH COMPONENTS {
      acaEeCertResponse
    })
  }
}
```


### <a name="RaAcaCertRequestSpdu"></a>RaAcaCertRequestSpdu
This structure is the SPDU used to send a signed RaAcaCertRequest.
 For the signature to be valid the signing certificate shall conform to the
 RA certificate profile given in 7.7.3.9, contain a PSID equal to
 SecurityMgmtPsid and a corresponding SSP containing the C-OER encoding of a
 SecurityMgmtSsp indicating RaSsp. The toBeSigned.certRequestPermissions
 field of the RA certificate shall permit the requested permissions in the
 raAcaCertRequest.tbsCert.appPermissions field.
```asn1
RaAcaCertRequestSpdu ::= Ieee1609Dot2Data-SignedCertRequest {
  ScmsPdu-Scoped {
    AcaRaInterfacePdu (WITH COMPONENTS {
      raAcaCertRequest
    })
  },
  SignerSingleCert
}
```


### <a name="AcaRaCertResponseSpdu"></a>AcaRaCertResponseSpdu
This structure is the SPDU used to send a signed AcaRaCertResponse.
 For the signature to be valid the signing certificate shall contain a PSID
 equal to SecurityMgmtPsid and a corresponding SSP containing the C-OER
 encoding of a SecurityMgmtSsp indicating AcaSsp.
```asn1
AcaRaCertResponseSpdu ::= Ieee1609Dot2Data-Signed {
  ScmsPdu-Scoped {
    AcaRaInterfacePdu (WITH COMPONENTS {
      acaRaCertResponse
    })
  },
  SecurityMgmtPsid
}
```


### <a name="CompositeCrlSpdu"></a>CompositeCrlSpdu
This structure is the SPDU used to send an unsecured CompositeCrl.
 It is used to create composite CRL files as specified in 8.5.
```asn1
CompositeCrlSpdu ::= Ieee1609Dot2Data-Unsecured {
  ScmsPdu-Scoped {
    CertManagementPdu (WITH COMPONENTS {
      compositeCrl
    })
  }
}
```


### <a name="CertificateChainSpdu"></a>CertificateChainSpdu
This structure is the SPDU used to send an unsecured
 CertificateChain. It is used to create certificate chain files as
 specified in 8.4.
```asn1
CertificateChainSpdu ::= Ieee1609Dot2Data-Unsecured {
  ScmsPdu-Scoped {
    CertManagementPdu (WITH COMPONENTS {
      certificateChain
    })
  }
}
```


### <a name="MultiSignedCtlSpdu"></a>MultiSignedCtlSpdu
This structure is the SPDU used to send an unsecured MultiSignedCtl.
```asn1
MultiSignedCtlSpdu ::= Ieee1609Dot2Data-Unsecured {
  ScmsPdu-Scoped {
    CertManagementPdu (WITH COMPONENTS {
      multiSignedCtl
    })
  }
}
```


### <a name="CtlSignatureSpdu"></a>CtlSignatureSpdu
This structure is the SPDU used to send a signed
 ToBeSignedCtlSignature. For the signature to be valid, the signing
 certificate shall match the elector certificate profile in 7.7.3.7. This
 means that the signature is calculated as specified in IEEE Std 1609.2,
 with the data input to the hash process consisting of the C-OER encoding
 of the tbsData that includes the ToBeSignedCtlSignature.
```asn1
CtlSignatureSpdu ::= Ieee1609Dot2Data-Signed {
  ScmsPdu-Scoped {
    CertManagementPdu (WITH COMPONENTS {
      tbsCtlSignature
    })
  },
  SecurityMgmtPsid
}
```


### <a name="EeEcaCertRequestSpdu"></a>EeEcaCertRequestSpdu
This structure is the SPDU used to send a signed
 CertManagementInfoStatus. For the signature to be valid the signing
 certificate shall conform to the RA certificate profile given in 7.7.3.9 or
 the DC certificate profile given in 7.7.3.10.

This structure is the SPDU used to send a signed EeEcaCertRequest,
 as follows:
   - If eeEcaCertRequest.canonicalId is not present, the EE signs this
 structure using the private key corresponding to the
 tbsCert.verifyKeyIndicator field of the EeEcaCertRequest.
   - If eeEcaCertRequest.canonicalId is present, the EE signs this
 structure using the canonical private key as specified in 4.1.4.2.
```asn1
EeEcaCertRequestSpdu ::= Ieee1609Dot2Data-SignedCertRequest {
  ScmsPdu-Scoped {
    EcaEeInterfacePdu (WITH COMPONENTS {
      eeEcaCertRequest
    })
  },
  SignerSelf
}
```


### <a name="EcaEeCertResponseSpdu"></a>EcaEeCertResponseSpdu
This structure is the SPDU used to send a signed EcaEeCertResponse.
 For the signature to be valid, the signing certificate shall contain a PSID
 equal to SecurityMgmtPsid and a corresponding SSP containing the C-OER
 encoding of a SecurityMgmtSsp indicating EcaSsp.
```asn1
EcaEeCertResponseSpdu ::= Ieee1609Dot2Data-Signed {
  ScmsPdu-Scoped {
    EcaEeInterfacePdu (WITH COMPONENTS {
      ecaEeCertResponse
    })
  },
  SecurityMgmtPsid
}
```


### <a name="EeRaCertRequestSpdu"></a>EeRaCertRequestSpdu
This structure is the SPDU used to send a signed then encrypted
 EeRaCertRequest. It is a choice of the IEEE 1609.2 authenticated
 certificate request, which may be any kind of EE-RA certificate request,
 and the ITU-T X.509 certificate request, which is required to be an
 authorization certificate request.
```asn1
EeRaCertRequestSpdu ::= Ieee1609Dot2Data (
  EeRa1609Dot2AuthenticatedCertRequestSpdu |
  EeRaX509AuthenticatedCertRequestSpdu
)
```


### <a name="EeRaX509AuthenticatedCertRequestSpdu"></a>EeRaX509AuthenticatedCertRequestSpdu
This structure is the SPDU used to send a signed then encrypted IEEE
 1609.2 authenticated certificate request. The EE signs this structure
 using its enrollment certificate. The enrollment certificate shall conform
 to the enrollment certificate profile given in 7.7.3.5. The EE encrypts
 the signed structure using the encryptionKey from the RA's certificate.

This structure is the SPDU used to send a signed then encrypted ITU-T
 X.509authenticated certificate request. The EE signs this structure
 using its enrollment certificate. The enrollment certificate shall conform
 to the enrollment certificate profile given in 7.7.3.6. The EE encrypts
 the signed structure using the encryptionKey from the RA's certificate.
```asn1
EeRaX509AuthenticatedCertRequestSpdu ::= Ieee1609Dot2Data-Encrypted {
  Ieee1609Dot2Data-SignedX509AuthenticatedCertRequest {
    ScmsPdu-Scoped {
      EeRaInterfacePdu (WITH COMPONENTS {
        eeRaCertRequest
      })
    },
    SignerSingleX509Cert
  }
}
```


### <a name="RaEeCertAckSpdu"></a>RaEeCertAckSpdu
This structure is the SPDU used to send a signed RaEeCertAck to
 acknowledge the receipt of an EeRaCertRequestSpdu. For the signature to be
 valid the signing certificate shall conform to the RA certificate profile
 given in 7.7.3.9.
```asn1
RaEeCertAckSpdu ::= Ieee1609Dot2Data-Signed {
  ScmsPdu-Scoped {
    EeRaInterfacePdu (WITH COMPONENTS {
      raEeCertAck
    })
  },
  SecurityMgmtPsid
}
```


### <a name="RaEeCertInfoSpdu"></a>RaEeCertInfoSpdu
This structure is the SPDU used to create an unsigned .info file
 to be included in a certificate batch zip file as specified in 8.2. This
 SPDU is used if the RaEeCertInfo does not contain an acpcTreeId field.
```asn1
RaEeCertInfoSpdu ::= Ieee1609Dot2Data-Unsecured {
  ScmsPdu-Scoped {
    EeRaInterfacePdu (WITH COMPONENTS {
      raEeCertInfo (WITH COMPONENTS {
        acpcTreeId ABSENT
      })
    })
  }
}
```


### <a name="RaEeCertAndAcpcInfoSpdu"></a>RaEeCertAndAcpcInfoSpdu
This structure is the SPDU used to create a signed .info file to
 be included in a certificate batch zip file as specified in 8.2. This
 SPDU is used if the RaEeCertInfo contains an acpcTreeId field. For the
 signature to be valid the signing certificate shall conform to the RA
 certificate profile given in 7.7.3.9.
```asn1
RaEeCertAndAcpcInfoSpdu ::= Ieee1609Dot2Data-Signed {
  ScmsPdu-Scoped {
    EeRaInterfacePdu (WITH COMPONENTS {
      raEeCertInfo (WITH COMPONENTS {
        acpcTreeId PRESENT
      })
    })
  },
  SecurityMgmtPsid
}
```


### <a name="EeRaDownloadRequestPlainSpdu"></a>EeRaDownloadRequestPlainSpdu
This structure is the SPDU used to send an unsecured
 EeRaDownloadRequest.
```asn1
EeRaDownloadRequestPlainSpdu ::= Ieee1609Dot2Data-Unsecured {
  ScmsPdu-Scoped {
    EeRaInterfacePdu (WITH COMPONENTS {
      eeRaDownloadRequest
    })
  }
}
```


### <a name="EeRaDownloadRequestSpdu"></a>EeRaDownloadRequestSpdu
This structure is the SPDU used to send a signed then encrypted
 EeRaDownloadRequest. The EE signs this structure using its enrollment
 certificate. The enrollment certificate shall conform to the enrollment
 certificate profile given in 7.7.3.5. The EE encrypts the signed
 structure using the encryptionKey from the RA's certificate.
```asn1
EeRaDownloadRequestSpdu ::= Ieee1609Dot2Data-SignedEncrypted {
  ScmsPdu-Scoped {
    EeRaInterfacePdu (WITH COMPONENTS {
      eeRaDownloadRequest
    })
  },
  SecurityMgmtPsid
}
```


### <a name="RaEeEnrollmentCertAckSpdu"></a>RaEeEnrollmentCertAckSpdu
This structure is the SPDU used to send a signed then encrypted
 EeEcaCertRequestSpdu. The EE signs this structure using its enrollment
 certificate. The enrollment certificate shall conform to the enrollment
 certificate profile given in 7.7.3.5. The EE encrypts the signed
 structure using the encryptionKey from the RA's certificate.

This structure is the SPDU used to send a signed RaEeCertInfo. For
 the signature to be valid the signing certificate shall conform to the RA
 certificate profile given in 7.7.3.9.
```asn1
RaEeEnrollmentCertAckSpdu ::= Ieee1609Dot2Data-Signed {
  ScmsPdu-Scoped {
    EeRaInterfacePdu (WITH COMPONENTS {
      raEeCertInfo (WITH COMPONENTS {
        acpcTreeId ABSENT
      })
    })
  },
  SecurityMgmtPsid
}
```

### <a name="SecurityMgmtSsp"></a>SecurityMgmtSsp
This parent structure defines the SSP for SecurityMgmtPsid and
 encompasses all SSP structures defined in this document. An overview of
 this structure is as follows:

Fields:
* elector of type [**ElectorSsp**](#ElectorSsp) <br>
  contains the SSP defined for an elector.


* root of type [**RootCaSsp**](#RootCaSsp) <br>
  contains the SSP defined for a root CA.


   
* pg of type [**PgSsp**](#PgSsp) <br>
  contains the SSP defined for a policy generator.


   
* ica of type [**IcaSsp**](#IcaSsp) <br>
  contains the SSP defined for an intermediate CA.


   
* eca of type [**EcaSsp**](#EcaSsp) <br>
  contains the SSP defined for an enrollment CA.


   
* aca of type [**AcaSsp**](#AcaSsp) <br>
  contains the SSP defined for an authorization CA.


   
* crl of type [**CrlSignerSsp**](#CrlSignerSsp) <br>
  contains the SSP defined for a CRL signer.


   
* dcm of type [**DcmSsp**](#DcmSsp) <br>
  contains the SSP defined for a device configuration manager.


   
* la of type [**LaSsp**](#LaSsp) <br>
  contains the SSP defined for a linkage authority.


   
* lop of type [**LopSsp**](#LopSsp) <br>
  contains the SSP defined for a location obscurer proxy.


   
* ma of type [**MaSsp**](#MaSsp) <br>
  contains the SSP defined for a misbehavior authority.


   
* ra of type [**RaSsp**](#RaSsp) <br>
  contains the SSP defined for a registration authority.


   
* ee of type [**EeSsp**](#EeSsp) <br>
  contains the SSP defined for an end entity.


   
* dc of type [**DcSsp**](#DcSsp) <br>
  contains the SSP defined for a distribution center.
   


   
     ...,

>>>
NOTE:&emsp;The LOP is in the SSP for backward compatibility reasons,
 and in practice, in this design the LOP does not have a certificate.
>>>
```asn1
SecurityMgmtSsp ::= CHOICE {
  elector  ElectorSsp,
  root     RootCaSsp,
  pg       PgSsp,
  ica      IcaSsp,
  eca      EcaSsp,
  aca      AcaSsp,
  crl      CrlSignerSsp,
  dcm      DcmSsp,
  la       LaSsp,
  lop      LopSsp,
  ma       MaSsp,
  ra       RaSsp,
  ee       EeSsp,
  ...,
  dc       DcSsp
  }
```


### <a name="TestSecurityMgmtSsp"></a>TestSecurityMgmtSsp
```asn1
TestSecurityMgmtSsp ::= SecurityMgmtSsp
```

### <a name="ElectorSsp"></a>ElectorSsp
This structure defines the SSP for an elector when it is authorizing
 SecurityMgmtPsid messages. It has no parameters other than the version
 number.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
```asn1
ElectorSsp ::= SEQUENCE {
  version  Uint8 (2),
  ...
}
```

### <a name="RootCaSsp"></a>RootCaSsp
This structure defines the SSP for a root CA when it is authorizing
 SecurityMgmtPsid messages. It has no parameters other than the version
 number.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
```asn1
RootCaSsp ::= SEQUENCE {
  version  Uint8 (2),
  ...
}
```

### <a name="PgSsp"></a>PgSsp
This structure defines the SSP for a policy generator when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
```asn1
PgSsp ::= SEQUENCE {
  version  Uint8 (2),
  ...
}
```

### <a name="IcaSsp"></a>IcaSsp
This structure defines the SSP for an intermediate CA when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
```asn1
IcaSsp ::= SEQUENCE {
  version  Uint8 (2),
  ...
}
```

### <a name="EcaSsp"></a>EcaSsp
This structure defines the SSP for an enrollment CA when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
```asn1
EcaSsp ::= SEQUENCE {
  version  Uint8 (2),
  ...
}
```

### <a name="AcaSsp"></a>AcaSsp
This structure defines the SSP for an authorization CA when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
```asn1
AcaSsp ::= SEQUENCE {
  version  Uint8 (2),
  ...
}
```

### <a name="CrlSignerSsp"></a>CrlSignerSsp
This structure defines the SSP for a CRL signer when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>

>>>
NOTE:&emsp;The SSP for a CRL signer when signing CRLs is associated with
 PSID 0x0100 and is defined in IEEE Std 1609.2.
>>>
```asn1
CrlSignerSsp ::= SEQUENCE {
  version  Uint8 (2),
  ...
}
```

### <a name="DcmSsp"></a>DcmSsp
This structure defines the SSP for a device configuration manager
 when it is authorizing SecurityMgmtPsid messages. It has no parameters
 other than the version number.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
```asn1
DcmSsp ::= SEQUENCE {
  version  Uint8 (2),
  ...
}
```

### <a name="LaSsp"></a>LaSsp
This structure defines the SSP for a linkage authority when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
* laId of type [**Uint16**](Ieee1609Dot2BaseTypes.md#Uint16) <br>
   
```asn1
LaSsp ::= SEQUENCE {
  version  Uint8 (2),
  laId     Uint16,
  ...
}
```

### <a name="LopSsp"></a>LopSsp
This structure defines the SSP for a location obscurer proxy (LOP)
 when it is authorizing SecurityMgmtPsid messages. It has no parameters
 other than the version number.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>

>>>
NOTE:&emsp;The LOP is in the SSP for backward compatibility reasons, and
 in practice, in this design the LOP does not have a certificate.
>>>
```asn1
LopSsp ::= SEQUENCE {
  version  Uint8 (2),
  ...
}
```

### <a name="MaSsp"></a>MaSsp
This structure defines the SSP for a misbehavior authority when it
 is authorizing SecurityMgmtPsid messages. Its parameters
 indicate the PSIDs associated with the misbehavior that is to be reported
 to that MA (see 4.1.5 for further details). The certificate containing
 this SSP is the MA Certificate to which an end entity should encrypt
 misbehavior reports related to the indicated PSIDs.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
* relevantPsids of type [**SequenceOfPsid**](Ieee1609Dot2BaseTypes.md#SequenceOfPsid) <br>
   
```asn1
MaSsp ::= SEQUENCE {
  version        Uint8 (2),
  relevantPsids  SequenceOfPsid,
  ...
}
```

### <a name="RaSsp"></a>RaSsp
This structure defines the SSP for an RA when it is authorizing
 SecurityMgmtPsid messages. It has no parameters other than the version
 number.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
```asn1
RaSsp ::= SEQUENCE {
  version  Uint8 (2),
  ...
}
```

### <a name="EeSsp"></a>EeSsp
This structure defines the SSP for an end entity when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8) (2)<br>
```asn1
EeSsp ::= SEQUENCE {
  version  Uint8(2),
  ...
}
```

### <a name="AcpcSsp"></a>AcpcSsp
This is a container for ACPC-related SSPs, specifying one SSP for
 each role. The only SSP defined in this document is the CamSsp, used in
 the CAM certificate that signs a SignedAprvBinaryTree or a
 SignedIndividualAprv. The SSP shall be C-OER encoded for inclusion in the
 CAM certificate. New versions of the CAM SSP should be handled by
 extending this structure rather than by use of a version number in the
 CamSsp structure.


 The AcpcSsp is associated with the AcpcPsid in the CAM certificate's
 appPermissions field.

Fields:
* cam of type [**CamSsp**](#CamSsp) <br>
```asn1
AcpcSsp ::= CHOICE {
  cam  CamSsp,
  ...
}
```


### <a name="CamSsp"></a>CamSsp
This is a list of the ACPC Tree IDs for which the containing CAM
 certificate is entitled to sign a SignedAprvBinaryTree or a
 SignedIndividualAprv. The SSP entitles the certificate holder to sign
 either of these structures.
```asn1
CamSsp ::= SEQUENCE (SIZE(1..MAX)) OF AcpcTreeId
```

### <a name="DcSsp"></a>DcSsp
This structure defines the SSP for a distribution center when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8) (2)<br>
```asn1
DcSsp ::= SEQUENCE {
  version  Uint8(2),
  ...
}
```



This structure defines the SSP for a policy generator when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.
  This structure defines the SSP for an intermediate CA when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.
  This structure defines the SSP for an enrollment CA when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.
  This structure defines the SSP for an authorization CA when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.
  This structure defines the SSP for a CRL signer when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.

>>>
NOTE:&emsp;The SSP for a CRL signer when signing CRLs is associated with
 PSID 0x0100 and is defined in IEEE Std 1609.2.
  This structure defines the SSP for a device configuration manager
 when it is authorizing SecurityMgmtPsid messages. It has no parameters
 other than the version number.
  This structure defines the SSP for a linkage authority when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.
  This structure defines the SSP for a location obscurer proxy (LOP)
 when it is authorizing SecurityMgmtPsid messages. It has no parameters
 other than the version number.
>>>


>>>
NOTE:&emsp;The LOP is in the SSP for backward compatibility reasons, and
 in practice, in this design the LOP does not have a certificate.
  This structure defines the SSP for a misbehavior authority when it
 is authorizing SecurityMgmtPsid messages. Its parameters
 indicate the PSIDs associated with the misbehavior that is to be reported
 to that MA (see 4.1.5 for further details). The certificate containing
 this SSP is the MA Certificate to which an end entity should encrypt
 misbehavior reports related to the indicated PSIDs.
  This structure defines the SSP for an RA when it is authorizing
 SecurityMgmtPsid messages. It has no parameters other than the version
 number.
  This structure defines the SSP for an end entity when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.
  This is a container for ACPC-related SSPs, specifying one SSP for
 each role. The only SSP defined in this document is the CamSsp, used in
 the CAM certificate that signs a SignedAprvBinaryTree or a
 SignedIndividualAprv. The SSP shall be C-OER encoded for inclusion in the
 CAM certificate. New versions of the CAM SSP should be handled by
 extending this structure rather than by use of a version number in the
 CamSsp structure.
>>>


 The AcpcSsp is associated with the AcpcPsid in the CAM certificate's
 appPermissions field.
  This is a list of the ACPC Tree IDs for which the containing CAM
 certificate is entitled to sign a SignedAprvBinaryTree or a
 SignedIndividualAprv. The SSP entitles the certificate holder to sign
 either of these structures.
  This structure defines the SSP for a distribution center when it is
 authorizing SecurityMgmtPsid messages. It has no parameters other than the
 version number.


