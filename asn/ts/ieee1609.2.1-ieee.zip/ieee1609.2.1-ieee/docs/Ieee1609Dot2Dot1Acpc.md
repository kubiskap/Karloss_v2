# ASN.1 module Ieee1609Dot2Dot1Acpc
 OID: _{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) acpc(18) major-version-3(3) minor-version-1(1)}_
 @note Section references in this file are to clauses in IEEE Std
 1609.2.1 unless indicated otherwise. Full forms of acronyms and
 abbreviations used in this file are specified in 3.2.
 

## Imports:
 * **[Ieee1609Dot2BaseTypes](Ieee1609Dot2BaseTypes.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) base(1) base-types(2) major-version-2(2) minor-version-3(3)} WITH SUCCESSORS*<br/>
  
 * **[Ieee1609Dot2Dot1Protocol](Ieee1609Dot2Dot1Protocol.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) extension-standards(255) dot1(1) interfaces(1) protocol(17) major-version-3(3) minor-version-1(1)} WITH SUCCESSORS*<br/>
  
## Data Elements:
### <a name="AcpcPdu"></a>AcpcPdu
This structure contains an APrV structure produced by the CAM. An
 overview of this structure is as follows:

Fields:
* tree of type [**AprvBinaryTree**](#AprvBinaryTree) <br>
  contains an AprvBinaryTree.


* aprv of type [**IndividualAprv**](#IndividualAprv) <br>
  contains a single IndividualAprv.
   


   
```asn1
AcpcPdu ::= CHOICE {
  tree  AprvBinaryTree,
  aprv  IndividualAprv,
  ...
}
```

### <a name="AprvBinaryTree"></a>AprvBinaryTree
This structure encodes a binary tree. An overview of this structure
 is as follows:

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
  contains the current version of the structure.


* generationTime of type [**Time32**](Ieee1609Dot2BaseTypes.md#Time32) <br>
  contains the generation time of AprvBinaryTree.


   
* currentI of type [**IValue**](Ieee1609Dot2BaseTypes.md#IValue) <br>
  contains the i-value associated with the batch of
   certificates.


   
* acpcTreeId of type [**AcpcTreeId**](#AcpcTreeId) <br>
  contains an identifier for the CAM creating this binary
   tree.


   
* hashAlgorithmId of type [**HashAlgorithm**](Ieee1609Dot2BaseTypes.md#HashAlgorithm) <br>
  contains the identifier of the hash algorithm used
   inside the binary tree.


   
* tree of type **BIT STRING** <br>
  contains a bit string indicating which nodes of the tree are
   present. It is calculated as specified in 9.5.4.2, and can be used by the
   EE to determine which entry in nodeValueList to use to derive that EE's
   APrV as specified in 9.5.2.


   
* nodeValueList of type **SEQUENCE**  (SIZE (1..MAX)) OF AcpcNodeValue<br>
  contains the values of the nodes that are present in
   the order indicated by tree.
   


   
```asn1
AprvBinaryTree ::= SEQUENCE {
  version          Uint8 (2),
  generationTime   Time32,
  currentI         IValue,
  acpcTreeId       AcpcTreeId,
  hashAlgorithmId  HashAlgorithm,
  tree             BIT STRING,
  nodeValueList    SEQUENCE (SIZE (1..MAX)) OF AcpcNodeValue,
  ...
}
```


### <a name="AcpcPsid"></a>AcpcPsid
This is the PSID used to indicate activities in ACPC as specified in
 this document.
```asn1
AcpcPsid ::= Psid(2113696)
```


### <a name="UnsecuredAprvBinaryTree"></a>UnsecuredAprvBinaryTree
This is used to wrap an AprvBinaryTree in an Ieee1609Dot2Data for
 transmission if the policy is that the AprvBinaryTree need not be signed.
 See 9.5.6 for discussion.
```asn1
UnsecuredAprvBinaryTree ::= Ieee1609Dot2Data-Unsecured {
	AcpcPdu (WITH COMPONENTS {
    tree
  })
}
```


### <a name="SignedAprvBinaryTree"></a>SignedAprvBinaryTree
This is used to wrap an AprvBinaryTree in an Ieee1609Dot2Data for
 transmission if the policy is that the AprvBinaryTree be signed. See 9.5.6
 for discussion.
```asn1
SignedAprvBinaryTree ::= Ieee1609Dot2Data-Signed {
  AcpcPdu (WITH COMPONENTS {
    tree
  }),
  AcpcPsid
}
```

### <a name="IndividualAprv"></a>IndividualAprv
This structure contains an individual APrV. An overview of this
 structure is as follows:

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
  contains the current version of the structure.


* generationTime of type [**Time32**](Ieee1609Dot2BaseTypes.md#Time32) <br>
  contains the generation time of IndividualAprv.


   
* currentI of type [**IValue**](Ieee1609Dot2BaseTypes.md#IValue) <br>
  contains the i-value associated with the batch of
   certificates.


   
* acpcTreeId of type [**AcpcTreeId**](#AcpcTreeId) <br>
  contains an identifier for the CAM creating this binary
   tree.


   
* nodeId of type **BIT STRING** <br>
  contains the identifier of the node.


   
* nodeValue of type [**AcpcNodeValue**](#AcpcNodeValue) <br>
  contains the value of the node.
   


   
```asn1
IndividualAprv ::= SEQUENCE {
  version         Uint8 (2),
  generationTime  Time32,
  currentI        IValue,
  acpcTreeId      AcpcTreeId,
  nodeId          BIT STRING,
  nodeValue       AcpcNodeValue,
  ...
}
```


### <a name="SignedIndividualAprv"></a>SignedIndividualAprv
This is used to wrap an IndividualAprv in an Ieee1609Dot2Data for
 transmission if the policy is that the IndividualAprv be signed. See 9.5.6
 for discussion.
```asn1
SignedIndividualAprv ::= Ieee1609Dot2Data-Signed {
  AcpcPdu (WITH COMPONENTS {
    aprv
  }),
  AcpcPsid
}
```


### <a name="AcpcTreeId"></a>AcpcTreeId
This is an 8 byte string that identifies an ACPC tree series. It is
 required to be globally unique within the system and is the same for all
 ACPC tree instances within the ACPC tree series. Registration of AcpcTreeId
 values is managed by the IEEE RA; see http://standards.ieee.org/regauth. A
 list of assigned AcpcTreeId values is provided in L.2.
```asn1
AcpcTreeId ::= OCTET STRING (SIZE(8))
```


### <a name="AcpcNodeValue"></a>AcpcNodeValue
This is a 16 byte string that represents the value of a node in the
 ACPC tree.
```asn1
AcpcNodeValue ::= OCTET STRING (SIZE(16))
```

### <a name="AprvHashCalculationInput"></a>AprvHashCalculationInput
This structure, C-OER encoded, is the input to the hash function to
 calculate child node values from a parent node. By including the ID fields
 it "firewalls" the hash function so that an attacker who inverts the hash
 has only found the hash preimage for a specific node, in a specific tree,
 for a specific time period. An overview of this structure is as follows:

Fields:
* version of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8)  (2)<br>
  contains the current version of the structure.


* acpcTreeId of type [**AcpcTreeId**](#AcpcTreeId) <br>
  contains an identifier for this ACPC tree series.


   
* acpcPeriod of type [**IValue**](Ieee1609Dot2BaseTypes.md#IValue) <br>
  contains an identifier for the time period for this tree.
   If the certificates for which this set of APrVs are intended have an IValue
   field, acpcPeriod in this structure shall be the IValue field in the
   certificates. How the RA and the CAM synchronize on this value is outside
   the scope of this document.


   
* childNodeId of type **BIT STRING** <br>
  contains a bit string of length l encoding the node
   location within the l'th level.


   
* parentNodeValue of type **OCTET STRING**  (SIZE(16))<br>
  contains the value of the parent node.
   


   
```asn1
AprvHashCalculationInput ::= SEQUENCE {
  version          Uint8 (2),
  acpcTreeId       AcpcTreeId,
  acpcPeriod       IValue,
  childNodeId      BIT STRING,
  parentNodeValue  OCTET STRING (SIZE(16)),
  ...
}
```



