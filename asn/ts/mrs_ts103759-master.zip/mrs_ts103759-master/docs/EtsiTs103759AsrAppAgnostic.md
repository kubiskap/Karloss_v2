# <a name="EtsiTs103759AsrAppAgnostic"></a>ASN.1 module EtsiTs103759AsrAppAgnostic
OID: _{itu-t(0) identified-organization(4) etsi(0) itsDomain(5) wg5(5) ts(103759) aid-specific(2) appAgnostic(270549119) major-version-1(1) minor-version-0(0)}_

## Data Elements:
### <a name="AsrAppAgnostic"></a>AsrAppAgnostic
This data type is defined as NULL for this version of the standard.
```asn1
AsrAppAgnostic ::= NULL
```



