# <a name="EtsiTs103759AsrDenm"></a>ASN.1 module EtsiTs103759AsrDenm
OID: _{itu-t(0) identified-organization(4) etsi(0) itsDomain(5) wg5(5) ts(103759) aid-specific(2) denm(37) major-version-1(1) minor-version-0(0)}_

## Data Elements:
### <a name="AsrDenm"></a>AsrDenm
This data type is defined as NULL for version 0 of this file.
```asn1
AsrDenm ::= NULL
```



