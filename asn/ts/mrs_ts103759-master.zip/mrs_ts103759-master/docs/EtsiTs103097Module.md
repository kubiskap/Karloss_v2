# <a name="EtsiTs103097Module"></a>ASN.1 module EtsiTs103097Module
OID: _{itu-t(0) identified-organization(4) etsi(0) itsDomain(5) wg5(5) secHeaders(103097) core(1) major-version-3(3) minor-version-1(1)}_

## Imports:
* **[Ieee1609Dot2](Ieee1609Dot2.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) base(1) schema(1) major-version-2(2) minor-version-4(4)} WITH SUCCESSORS*<br/>
* **[EtsiTs103097ExtensionModule](EtsiTs103097ExtensionModule.md)** *{itu-t(0) identified-organization(4) etsi(0) itsDomain(5) wg5(5) secHeaders(103097) extension(2) major-version-1(1) minor-version-1(1)}*<br/>
## Data Elements:
### <a name="EtsiTs103097Certificate"></a>EtsiTs103097Certificate
```asn1
EtsiTs103097Certificate::= Certificate (WITH COMPONENTS{...,
  toBeSigned (WITH COMPONENTS{...,
    id (WITH COMPONENTS{...,
      linkageData ABSENT,
      binaryId ABSENT
    }),
    certRequestPermissions ABSENT,
    canRequestRollover ABSENT
  })
})
```

### <a name="EtsiTs103097Data"></a>EtsiTs103097Data
```asn1
EtsiTs103097Data::=Ieee1609Dot2Data (WITH COMPONENTS {..., 
  content (WITH COMPONENTS {...,
    signedData (WITH COMPONENTS {..., 
      tbsData (WITH COMPONENTS {              
        headerInfo (WITH COMPONENTS {...,
          generationTime PRESENT,
          p2pcdLearningRequest ABSENT,
          missingCrlIdentifier ABSENT
        })
      }),
      signer (WITH COMPONENTS {...,  
        certificate ((WITH COMPONENT (EtsiTs103097Certificate))^(SIZE(1)))
      })
    }),
    encryptedData (WITH COMPONENTS {..., 
      recipients  (WITH COMPONENT (
        (WITH COMPONENTS {..., 
          pskRecipInfo ABSENT,
          symmRecipInfo ABSENT,
          rekRecipInfo ABSENT
        })
      ))
    }),
    signedCertificateRequest ABSENT
  })
})
```

### <a name="EtsiTs103097Data-Unsecured"></a>EtsiTs103097Data-Unsecured
```asn1
EtsiTs103097Data-Unsecured {ToBeSentDataContent} ::= EtsiTs103097Data (WITH COMPONENTS {...,
  content (WITH COMPONENTS {
    unsecuredData (CONTAINING ToBeSentDataContent)
  })
})
```

### <a name="EtsiTs103097Data-Signed"></a>EtsiTs103097Data-Signed
```asn1
EtsiTs103097Data-Signed {ToBeSignedDataContent} ::= EtsiTs103097Data (WITH COMPONENTS {..., 
  content (WITH COMPONENTS {
    signedData (WITH COMPONENTS {..., 
      tbsData (WITH COMPONENTS {
        payload (WITH COMPONENTS { 
          data (WITH COMPONENTS {...,
            content (WITH COMPONENTS {
              unsecuredData (CONTAINING ToBeSignedDataContent)
            })
          }) PRESENT
        })
      })
    })
  })
})
```

### <a name="EtsiTs103097Data-SignedExternalPayload"></a>EtsiTs103097Data-SignedExternalPayload
```asn1
EtsiTs103097Data-SignedExternalPayload ::= EtsiTs103097Data (WITH COMPONENTS {..., 
  content (WITH COMPONENTS {
    signedData (WITH COMPONENTS {..., 
      tbsData (WITH COMPONENTS {
        payload (WITH COMPONENTS {
          extDataHash (WITH COMPONENTS {
            sha256HashedData PRESENT
          }) PRESENT
        })
      })
    })
  })
})
```

### <a name="EtsiTs103097Data-Encrypted"></a>EtsiTs103097Data-Encrypted
```asn1
EtsiTs103097Data-Encrypted {ToBeEncryptedDataContent} ::= EtsiTs103097Data (WITH COMPONENTS {...,
  content (WITH COMPONENTS {
    encryptedData (WITH COMPONENTS {...,
      ciphertext (WITH COMPONENTS {...,
        aes128ccm (WITH COMPONENTS {...,
          ccmCiphertext (CONSTRAINED BY { ToBeEncryptedDataContent}) 
        })
      })
    })
  })
})
```

### <a name="EtsiTs103097Data-SignedAndEncrypted"></a>EtsiTs103097Data-SignedAndEncrypted
```asn1
EtsiTs103097Data-SignedAndEncrypted {ToBesignedAndEncryptedDataContent} ::= EtsiTs103097Data-Encrypted {EtsiTs103097Data-Signed {ToBesignedAndEncryptedDataContent}}
```

### <a name="EtsiTs103097Data-Encrypted-Unicast"></a>EtsiTs103097Data-Encrypted-Unicast
```asn1
EtsiTs103097Data-Encrypted-Unicast {ToBeEncryptedDataContent} ::= EtsiTs103097Data-Encrypted { EtsiTs103097Data-Unsecured{ToBeEncryptedDataContent}} (WITH COMPONENTS {...,
  content (WITH COMPONENTS {
    encryptedData (WITH COMPONENTS {...,
      recipients (SIZE(1))
    })
  })
})
```

### <a name="EtsiTs103097Data-SignedAndEncrypted-Unicast"></a>EtsiTs103097Data-SignedAndEncrypted-Unicast
```asn1
EtsiTs103097Data-SignedAndEncrypted-Unicast {ToBesignedAndEncryptedDataContent} ::= EtsiTs103097Data-Encrypted {EtsiTs103097Data-Signed {ToBesignedAndEncryptedDataContent}} (WITH COMPONENTS {...,
  content (WITH COMPONENTS {
    encryptedData (WITH COMPONENTS {...,
      recipients (SIZE(1))
    })
  })
})
```



