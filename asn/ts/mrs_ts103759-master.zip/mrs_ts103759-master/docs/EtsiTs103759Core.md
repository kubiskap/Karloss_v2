# <a name="EtsiTs103759Core"></a>ASN.1 module EtsiTs103759Core
OID: _{itu-t(0) identified-organization(4) etsi(0) itsDomain(5) wg5(5) ts(103759) general(1) core(1) major-version-1(1) minor-version-1(1)}_

## Imports:
* **[EtsiTs103097Module](EtsiTs103097Module.md)** *{itu-t(0) identified-organization(4) etsi(0) itsDomain(5) wg5(5) secHeaders(103097) core(1) major-version-3(3) minor-version-1(1)} WITH SUCCESSORS*<br/>
* **[Ieee1609Dot2BaseTypes](Ieee1609Dot2BaseTypes.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) base(1) base-types(2) major-version-2(2) minor-version-4(4)} WITH SUCCESSORS*<br/>
* **[EtsiTs103759AsrAppAgnostic](EtsiTs103759AsrAppAgnostic.md)** *{itu-t(0) identified-organization(4) etsi(0) itsDomain(5) wg5(5) ts(103759) aid-specific(2) appAgnostic(270549119) major-version-1(1) minor-version-0(0)} WITH SUCCESSORS*<br/>
* **[EtsiTs103759AsrCam](EtsiTs103759AsrCam.md)** *{itu-t(0) identified-organization(4) etsi(0) itsDomain(5) wg5(5) ts(103759) aid-specific(2) cam(36) major-version-1(1) minor-version-0(0)} WITH SUCCESSORS*<br/>
* **[EtsiTs103759AsrDenm](EtsiTs103759AsrDenm.md)** *{itu-t(0) identified-organization(4) etsi(0) itsDomain(5) wg5(5) ts(103759) aid-specific(2) denm(37) major-version-1(1) minor-version-0(0)} WITH SUCCESSORS*<br/>
* **[SaeJ3287AsrBsm](SaeJ3287AsrBsm.md)** *{joint-iso-itu-t(2) country(16) us(840) organization(1) sae(114566) v2x-communications(1) technical-committees(1) v2x-security(4) technical-reports(1) misbehavior-reporting(1) asn1-module(1) aid-specific(2) bsm(32) major-version-1(1) minor-version-0(0)} WITH SUCCESSORS*<br/>
## Data Elements:
### <a name="EtsiTs103759Data"></a>EtsiTs103759Data
This data type is the general PDU for a misbehaviour report from an 
 ITS-S to the MA responsible for reports of that type.

 AID-specific modules (EtsiTs103759AsrAppAgnostic, EtsiTs103759AsrCam, 
 EtsiTs103759AsrDenm, SaeJ3287AsrBsm) have been imported using `WITH SUCCESSORS`
 to enable importing one or more of those modules with minor-version greater 
 than `0` without requiring any change in the import statements. At least one of
 these AID-specific modules shall have minor-version greater than `0`.

* _version_ of type [**Uint8**](Ieee1609Dot2BaseTypes.md#Uint8) <br>
  contains the version number of this PDU definition. For this
   version of this data type it shall be equal to `2`.

* _generationTime_ of type [**Time64**](Ieee1609Dot2BaseTypes.md#Time64) <br>
  contains information on when this PDU was generated.

* _observationLocation_ of type [**ThreeDLocation**](Ieee1609Dot2BaseTypes.md#ThreeDLocation) <br>
  is the location at which the last observation of
   a V2X PDU was made before the decision was taken to generate a report.

* _report_ of type [**AidSpecificReport**](#AidSpecificReport) <br>
  contains the AID-specific misbehaviour report.
   

```asn1
EtsiTs103759Data ::= SEQUENCE {
  version              Uint8,
  generationTime       Time64, 
  observationLocation  ThreeDLocation, 
  report               AidSpecificReport 
}
```

### <a name="EtsiTs103759Data-SignedAndEncrypted-Unicast"></a>EtsiTs103759Data-SignedAndEncrypted-Unicast
This structure is the SPDU used to send a signed and encrypted 
 [**EtsiTs103759Data**](#EtsiTs103759Data) to the MA.

 For the signature to be valid the signing certificate shall conform to the
 authorization ticket profile given in clause 7.2.1 of ETSI TS 103 097 v2.1.1,
 where the appPermissions field in the authorization ticket allows signing of 
 misbehaviour reports. The signed [**EtsiTs103759Data**](#EtsiTs103759Data) shall be encrypted 
 to the MA using the encryption key in the MA's certificate.
```asn1
EtsiTs103759Data-SignedAndEncrypted-Unicast ::= 
  EtsiTs103097Data-SignedAndEncrypted-Unicast {
  EtsiTs103759Data
}
```

### <a name="AidSpecificReport"></a>AidSpecificReport
This data type is the whole report on issues detected for a specific ITS-AID.
 This ITS-AID may identify an individual application, or may identify
 cross-application or non-application-specific misbehaviour cases.

* _aid_ of type [**C-ASR**](#C-ASR) .&aid ({SetAsr})<br>
  contains the respective ITS-AID.

* _content_ of type [**C-ASR**](#C-ASR) .&Content ({SetAsr}{@.aid})<br>
  contains the report contents, e.g., [**AsrCam**](EtsiTs103759AsrCam.md#AsrCam). This will be a 

[**TemplateAsr**](EtsiTs103759BaseTypes.md#TemplateAsr) instantiated with AID-specific Information Object Sets.
```asn1
AidSpecificReport ::= SEQUENCE {
  aid      C-ASR.&aid ({SetAsr}),
  content  C-ASR.&Content ({SetAsr}{@.aid})
}
```

### <a name="C-ASR"></a>C-ASR
This data type defines the IOC for [**AidSpecificReport**](#AidSpecificReport).

* _aid_ of type [**Psid**](Ieee1609Dot2BaseTypes.md#Psid)  UNIQUE<br>
  contains the globally unique reference identifier of an 
   AID-specific misbehaviour report.

* Content<br>
  contains the open type of the PDU identified by aid. This 
   will be a [**TemplateAsr**](EtsiTs103759BaseTypes.md#TemplateAsr) instantiated with AID-specific Information Object
   Sets. 
   

```asn1
C-ASR ::= CLASS {
  &aid      Psid UNIQUE, 
  &Content   
} WITH SYNTAX {&Content IDENTIFIED BY &aid}
```

### <a name="SetAsr"></a>SetAsr
This data type defines the IOS for AidSpecificReport.

 See the ASN.1 modules where each set is defined for a description of that set.
```asn1
SetAsr C-ASR ::= {
  {AsrAppAgnostic IDENTIFIED BY c-AsrAppAgnostic} |
  {AsrCam         IDENTIFIED BY c-AsrCam} |
  {AsrDenm        IDENTIFIED BY c-AsrDenm}, 
  ...,
  {AsrBsm         IDENTIFIED BY c-AsrBsm}
}
```


>>>
NOTE:&emsp;This value is used for suspicious observations that are not
 or cannot be linked to a specific application.
>>>
```asn1
c-AsrAppAgnostic Psid ::= 270549119
```

```asn1
c-AsrCam Psid ::= 36
```

```asn1
c-AsrDenm Psid ::= 37
```

```asn1
c-AsrBsm Psid ::= 32
```



