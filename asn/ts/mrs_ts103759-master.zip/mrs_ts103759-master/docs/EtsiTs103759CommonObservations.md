# <a name="EtsiTs103759CommonObservations"></a>ASN.1 module EtsiTs103759CommonObservations
OID: _{itu-t(0) identified-organization(4) etsi(0) itsDomain(5) wg5(5) ts(103759) general(1) common-observations(2) major-version-1(1) minor-version-1(1)}_

## Imports:
* **[EtsiTs103759BaseTypes](EtsiTs103759BaseTypes.md)** *{itu-t(0) identified-organization(4) etsi(0) itsDomain(5) wg5(5) ts(103759) general(1) base-types(3) major-version-1(1) minor-version-1 (1)} WITH SUCCESSORS*<br/>
* **[Ieee1609Dot2BaseTypes](Ieee1609Dot2BaseTypes.md)** *{iso(1) identified-organization(3) ieee(111) standards-association-numbered-series-standards(2) wave-stds(1609) dot2(2) base(1) base-types(2) major-version-2(2) minor-version-4(4)} WITH SUCCESSORS*<br/>
## Data Elements:
### <a name="IdMbObs"></a>IdMbObs
This is the identifier for an observation within a target property,
 e.g., speed or security, so the values need to be unique within the target.

 The values of `v2xPduEvidence` and `nonV2xPduEvidence` fields of [**TemplateAsr**](EtsiTs103759BaseTypes.md#TemplateAsr)
 are observation-specific, so they are specified for each of the observations
 below. The trigger conditions are application-specific, so they are
 specified in AID-specific report modules, such as
 [**EtsiTs103759AsrCam**](EtsiTs103759AsrCam.md)).
```asn1
IdMbObs ::= Uint8
```

### <a name="Beacon-IntervalTooSmall"></a>Beacon-IntervalTooSmall
This data type is provided for an observation of beacon interval
 that is too small. This doesn't apply to repeated PDUs, but only to two 
 distinct PDUs.

   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex` 
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points to
 the PDU whose interval since the previous PDU is being flagged as too small.
 The `v2xPdus` field in that entry must contain at least the subject PDU
 and the PDU that immediately preceded it. 
 The PDUs may be of any supported type and shall be of type 
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in the same 
 report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
Beacon-IntervalTooSmall ::= NULL
c-ObsBeacon-IntervalTooSmall  IdMbObs::= 1 
obs-Beacon-IntervalTooSmall C-ASR-SINGLE-OBS ::= 
  {Beacon-IntervalTooSmall BY c-ObsBeacon-IntervalTooSmall}
```

### <a name="Static-Change"></a>Static-Change
This data type is provided for an observation of change in static 
 fields. The semantics of the `BIT STRING` are provided in the 
 application-specific files.

   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex` 
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points to
 the PDU whose one or more static fields since the previous PDU is being 
 flagged as changed.
 The `v2xPdus` field in that entry must contain at least the subject PDU
 and the PDU that immediately preceded it.
 The PDUs may be of any supported type and shall be of type
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in 
 the same report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
Static-Change ::= BIT STRING
c-ObsStatic-Change  IdMbObs::= 1 
obs-Static-Change C-ASR-SINGLE-OBS ::= 
  {Static-Change BY c-ObsStatic-Change}
```

### <a name="Security-MessageIdIncWithHeaderInfo"></a>Security-MessageIdIncWithHeaderInfo
This data type is provided for an observation, where the messageID
 is inconsistent with the psid in the security headerInfo.

   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex`
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points
 to the PDU for which the `messageId` is being flagged as inconsistent 
 with the `psid` in the security `headerInfo`.
 The `v2xPdus` field in that entry must contain at least the subject PDU.
 The PDU may be of any supported type and shall be of type 
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in the 
 same report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
Security-MessageIdIncWithHeaderInfo ::= NULL
c-ObsSecurity-MessageIdIncWithHeaderInfo IdMbObs ::= 1
obs-Security-MessageIdIncWithHeaderInfo C-ASR-SINGLE-OBS ::= { 
  Security-MessageIdIncWithHeaderInfo BY 
    c-ObsSecurity-MessageIdIncWithHeaderInfo
}
```

### <a name="Security-HeaderIncWithSecurityProfile"></a>Security-HeaderIncWithSecurityProfile
This data type is provided for an observation, where the security 
 `headerInfo` is inconsistent with the security profile for that `psid`. 

   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex`
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points to
 the PDU for which the security `headerInfo` is being flagged as inconsistent
 with the security profile for that `psid`. 
 The `v2xPdus` field in that entry must contain at least the subject PDU. The 
 PDU may be of any supported type and shall be of type 
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in the same 
 report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
Security-HeaderIncWithSecurityProfile ::= NULL
c-ObsSecurity-HeaderIncWithSecurityProfile IdMbObs ::= 2
obs-Security-HeaderIncWithSecurityProfile C-ASR-SINGLE-OBS ::= { 
  Security-HeaderIncWithSecurityProfile BY 
    c-ObsSecurity-HeaderIncWithSecurityProfile 
}
```

### <a name="Security-HeaderPsidIncWithCertificate"></a>Security-HeaderPsidIncWithCertificate
This data type is provided for an observation, where the `psid` in the
 security `headerInfo` is inconsistent with the psid in the certificate.

   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex` 
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points to
 the PDU for which the `psid` in the security `headerInfo` is being flagged
 as inconsistent with the `psid` in the certificate.
 The `v2xPdus` field in that entry must contain at least the 
 subject PDU.
 The PDU may be of any supported type and shall be of type 
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in the 
 same report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
Security-HeaderPsidIncWithCertificate ::= NULL
c-ObsSecurity-HeaderPsidIncWithCertificate IdMbObs ::= 3
obs-Security-HeaderPsidIncWithCertificate C-ASR-SINGLE-OBS ::= { 
  Security-HeaderPsidIncWithCertificate BY 
    c-ObsSecurity-HeaderPsidIncWithCertificate 
}
```

### <a name="Security-MessageIncWithSsp"></a>Security-MessageIncWithSsp
This data type is provided for an observation, where the message is
 is inconsistent with the SSP in the certificate.

   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex` 
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points
 to the PDU whose content is being flagged as inconsisent with the SSP 
 in the certificate.
 The `v2xPdus` field in that entry must contain at least the subject PDU.
 The PDU may be of any supported type and shall be of type 
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in the
 same report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
Security-MessageIncWithSsp ::= NULL
c-ObsSecurity-MessageIncWithSsp IdMbObs ::= 4
obs-Security-MessageIncWithSsp C-ASR-SINGLE-OBS ::= { 
  Security-MessageIncWithSsp BY c-ObsSecurity-MessageIncWithSsp 
}
```

### <a name="Security-HeaderTimeOutsideCertificateValidity"></a>Security-HeaderTimeOutsideCertificateValidity
This data type is provided for an observation, where the `generationTime`
 in the security `headerInfo` is outside the validity period of the certificate.

   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex` 
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points to
 the PDU for which the `generationTime` in the security `headerInfo` is being
 flagged as outside the validity period in the certificate.
 The `v2xPdus` field in that entry must contain at least the subject PDU.
 The PDU may be of any supported type and shall be of type 
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in the 
 same report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
Security-HeaderTimeOutsideCertificateValidity ::= NULL
c-ObsSecurity-HeaderTimeOutsideCertificateValidity IdMbObs ::= 5
obs-Security-HeaderTimeOutsideCertificateValidity C-ASR-SINGLE-OBS ::= {
  Security-HeaderTimeOutsideCertificateValidity BY 
    c-ObsSecurity-HeaderTimeOutsideCertificateValidity 
}
```

### <a name="Security-MessageLocationOutsideCertificateValidity"></a>Security-MessageLocationOutsideCertificateValidity
This data type is provided for an observation, where the location
 in the message is outside the validity region in the certificate.

   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex`
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points
 to the PDU for which the location in the PDU is being flagged as outside
 the validity region in the certificate.
 The `v2xPdus` field in that entry must contain at least the subject PDU.
 The PDU may be of any supported type and shall be of type 
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in the same
 report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
Security-MessageLocationOutsideCertificateValidity ::= NULL
c-ObsSecurity-MessageLocationOutsideCertificateValidity IdMbObs ::= 6
obs-Security-MessageLocationOutsideCertificateValidity C-ASR-SINGLE-OBS ::= { 
  Security-MessageLocationOutsideCertificateValidity BY 
    c-ObsSecurity-MessageLocationOutsideCertificateValidity 
}
```

### <a name="Security-HeaderLocationOutsideCertificateValidity"></a>Security-HeaderLocationOutsideCertificateValidity
This data type is provided for an observation, where the 
 `generationLocation` in the security `headerInfo` is outside the validity region
 in the certificate.

   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex` 
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points to
 the PDU for which the `generationLocation` inthe security `headerInfo` is being
 flagged as outside the validity region in the certificate.
 The `v2xPdus` field in that entry must contain at least the subject PDU.
 The PDU may be of any supported type and shall be of type 
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in the same 
 report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
Security-HeaderLocationOutsideCertificateValidity ::= NULL
c-ObsSecurity-HeaderLocationOutsideCertificateValidity IdMbObs ::= 7
obs-Security-HeaderLocationOutsideCertificateValidity C-ASR-SINGLE-OBS ::= { 
  Security-HeaderLocationOutsideCertificateValidity BY 
    c-ObsSecurity-HeaderLocationOutsideCertificateValidity 
}
```

### <a name="Position-ChangeTooLarge"></a>Position-ChangeTooLarge
This data type is provided for an observation of change in position 
 that is too large.

   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex` 
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points to
 the PDU whose position is being flagged as inconsistent with the previous PDU.
 The `v2xPdus` field in that entry must contain at least the subject PDU and
 the PDU that immediately preceded it. 
 The PDU may be of any supported type and shall be of type 
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in the same 
 report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
Position-ChangeTooLarge ::= NULL
c-ObsPosition-ChangeTooLarge IdMbObs ::= 4 
obs-Position-ChangeTooLarge C-ASR-SINGLE-OBS ::= { 
  Position-ChangeTooLarge BY c-ObsPosition-ChangeTooLarge 
}
```

### <a name="Speed-ValueTooLarge-VehicleType"></a>Speed-ValueTooLarge-VehicleType
This data type is provided for an observation of speed too large
 for a given vehicle type.

   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex` 
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points to
 the PDU whose speed is being flagged as too large for the vehicle type.
 The `v2xPdus` field in that entry must contain at least the subject PDU.
 The PDU may be of any supported type and shall be of type
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in the
 same report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
Speed-ValueTooLarge-VehicleType ::= NULL
c-ObsSpeed-ValueTooLarge-VehicleType IdMbObs::= 3
obs-Speed-ValueTooLarge-VehicleType C-ASR-SINGLE-OBS ::= { 
 Speed-ValueTooLarge-VehicleType BY c-ObsSpeed-ValueTooLarge-VehicleType 
}
```

### <a name="Speed-ValueTooLarge-DriveDirectionReverse"></a>Speed-ValueTooLarge-DriveDirectionReverse
This data type is provided for an observation of speed too large
 for the reverse drive direction.
 
   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex` 
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points to 
 the PDU whose speed is being flagged as too large for the reverse drive direction.
 The `v2xPdus` field in that entry must contain at least the subject PDU.
 The PDU may be of any supported type and shall be of type 
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in the same
 report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
Speed-ValueTooLarge-DriveDirectionReverse ::= NULL
c-ObsSpeed-ValueTooLarge-DriveDirectionReverse IdMbObs::= 4
obs-Speed-ValueTooLarge-DriveDirectionReverse C-ASR-SINGLE-OBS ::= { 
  Speed-ValueTooLarge-DriveDirectionReverse BY 
    c-ObsSpeed-ValueTooLarge-DriveDirectionReverse 
}
```

### <a name="Speed-ChangeTooLarge"></a>Speed-ChangeTooLarge
This data type is provided for an observation of change in speed 
 that is too large. 

   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex`
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points to
 the PDU whose speed is being flagged as inconsistent with the speed
 in the previous PDU.
 The `v2xPdus` field in that entry must contain at least the subject PDU
 and the PDU that immediately preceded it.
 The PDU may be of any supported type and shall be of type 
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in the 
 same report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
Speed-ChangeTooLarge ::= NULL
c-ObsSpeed-ChangeTooLarge IdMbObs::= 5
obs-Speed-ChangeTooLarge C-ASR-SINGLE-OBS ::= { 
  Speed-ChangeTooLarge BY c-ObsSpeed-ChangeTooLarge 
}
```

### <a name="LongAcc-ValueTooLarge"></a>LongAcc-ValueTooLarge
This data type is provided for an observation of longitudinal
 acceleration that is too large. 

   - `v2xPduEvidence`: This field must contain at least one entry.
 The observation applies to the first entry. The `subjectPduIndex` 
 in that [**V2xPduStream**](EtsiTs103759BaseTypes.md#V2xPduStream) points to
 the PDU whose longitudinal acceleration is being flagged as too large. 
 The `v2xPdus` field in that entry must contain at least the subject PDU.
 The PDU may be of any supported type and shall be of type 
 `c-MbObsMsg-ieee1609Dot2Data` unless another observation included in the 
 same report requires a different PDU type.

   - `nonV2xPduEvidence`: No other evidence is required to be included 
 to support this observation.
```asn1
LongAcc-ValueTooLarge ::= NULL
c-ObsLongAcc-ValueTooLarge IdMbObs::= 4
obs-LongAcc-ValueTooLarge C-ASR-SINGLE-OBS ::= { 
  LongAcc-ValueTooLarge BY c-ObsLongAcc-ValueTooLarge 
}
```



