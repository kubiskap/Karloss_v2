# ASN.1 module for IEEE 1609.2

The module was published as a part of delivery **[ETSI TS 103 097 v2.1.1](http://www.etsi.org/deliver/etsi_ts/103000_103099/103097/02.01.01_60/ts_103097v020101p.pdf)**

The module contains extensions published with IEEE 1609.2.1
